<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/user_options.css">
<div class='option'>
	<ul class='option'>
		<li class='option'><a class='option' id='profile' href='<?php echo base_url();?>index.php/account/show'>My profile</a></li>
		<li class='option'><a class='option' id='edit_profile' href='<?php echo base_url();?>index.php/account/edit_profile'>Edit profile</a></li>
		<li class='option'><a class='option' id='add_address' href='<?php echo base_url();?>index.php/account/add_address'>Add new address</a></li>
		<li class='option'><a class='option' id='edit_address' href='<?php echo base_url();?>index.php/account/edit_address'>Edit address</a></li>
		<li class='option'><a class='option' id='shopping_cart' href='<?php echo base_url();?>index.php/shopping_cart/show'>Shopping cart</a></li>
		<li class='option'><a class='option' id='order_history' href='<?php echo base_url();?>index.php/order/show'>Order history</a></li>
	</ul>
</div>
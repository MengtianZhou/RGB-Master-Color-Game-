<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/order_detail.css">
<div class="order_detail">
	<table>
		<tr>
			<th>ITEM IMAGE</th>
			<th>ITEM NAME</th>
			<th>SIZE</th>
			<th>PRICE</th>
			<th>QUANTITY</th>
			<th>TOTAL</th>
		</tr>
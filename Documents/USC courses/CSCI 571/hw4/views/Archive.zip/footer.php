<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/footer.css">
		<div class="footer">
			<p class="footer">Copyrigth&copy; 2014-2024 by Mengtian Zhou</p>
			<p class="footer">All Rights Reserved.</p>
		</div>
	</body>
</html>

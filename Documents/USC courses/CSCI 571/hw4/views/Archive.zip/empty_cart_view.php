<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/empty_cart.css">
<div class='empty_cart'>
	<a href='<?php echo base_url();?>index.php/products/show_products_by_category/1'><img class='empty_cart' src='<?php echo base_url();?>img/website/emptyCart.gif'></a>
</div>
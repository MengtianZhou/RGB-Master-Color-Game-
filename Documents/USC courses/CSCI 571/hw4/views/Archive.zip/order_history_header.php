<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/order_history.css">
<div class='order_history'>
	<table>
		<tr>
			<th>ORDER DATE</th>
			<th>SHIP TO</th>
			<th>BILL TO</th>
			<th>DETAIL</th>
		</tr>
			

			</table>	
		<input type='submit' name='edit' value='edit' class='button'>
		<input type='submit' name='delete' value='delete' class='button'>
	</form>
</div>
		</table>
		<div class="amount">Amount:&nbsp;$&nbsp;<p id="amount"><?php echo $amount;?></p></div>	
		<div class='buttons'>
			<input type='submit' class='button' name='submit' value="continue shopping" style="background:#04B486; color:white; text-weight:bold; width:20%; height:5%; font-size:16px;margin:10px">
			<input type='submit' class='button' name='submit' value="empty" style="background:#2E9AFE; color:white; text-weight:bold; width:10%; height:5%; font-size:16px;margin:10px">
			<input type="submit" class="button" name="submit" value="delete" style="background:#FE2E2E; color:white; text-weight:bold; width:10%; height:5%; font-size:16px; margin:10px">
			<input type="submit" class="button" name="submit" value="edit" style="background:#31B404; color:white; text-weight:bold; width:10%; height:5%; font-size:16px;margin:10px">
			<input type="submit" class="button" name="submit" value="check out" style="background:#FF8000; color:white; text-weight:bold; width:10%; height:5%; font-size:16px;margin:10px">
		</div>	
	</form>	
</div>
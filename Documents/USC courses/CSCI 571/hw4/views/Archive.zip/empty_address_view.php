<link rel='stylesheet' type='text/css' href='<?php echo base_url();?>css/empty_address.css'>
<div class="no_address">
	<table>
		<caption>Address List</caption>
		<tr>
			<td>No address existed, please <a href='<?php echo base_url();?>index.php/account/add_address'>add one</a>.</td>
		</tr>
	</table>
</div>
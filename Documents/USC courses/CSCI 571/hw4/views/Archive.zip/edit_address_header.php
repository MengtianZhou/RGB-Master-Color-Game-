<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/edit_address.css">
<div class="edit_address">
	<form action='<?php echo base_url();?>index.php/account/edit_selected_add' method='post'>
		<table>
			<caption>Select an address to edit</caption>
			
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/empty_order_history.css">
<div class='empty_order_history'>
	<p class="notice">There is no order history, <a href='<?php echo base_url();?>index.php/products/show_products_by_category/1'>Shopping now</a>!</p>
	<img class='empty' src='<?php echo base_url();?>img/website/empty_order.jpg'>
</div>
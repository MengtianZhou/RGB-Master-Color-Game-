<div class="top2">
	<link rel="stylesheet" type='text/css' href='<?php echo base_url();?>css/menu.css'>
	<img class="top2" src="<?php echo base_url();?>img/website/red_camera_icon.png">
	<ul clss="top2">
		<li class="top2"><a class="top2" id="home" href="<?php echo base_url();?>index.php/home">Home</a></li>
		<li class="top2"><a class="top2" id="products" href="<?php echo base_url();?>index.php/products/show_products_by_category/1">Products</a></li>
		<li class="top2"><a class="top2" id="order_instruction" href="">Order Instruction</a></li>
		<li class="top2"><a class="top2" id="about_us" href="">About Us</a></li>
		<li class="top2"><a class="top2" id="contect_us" href="">Contect Us</a></li>
	</ul>
</div>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/shopping_cart.css">
<div class='shopping_cart'>
	<form action='<?php echo base_url();?>index.php/shopping_cart/edit' method='post'>
		<table>
			<tr>
				<th>select</th>
				<th>product</th>
				<th>name</th>
				<th>size</th>
				<th>price</th>
				<th>quantity</th>
			</tr>
			

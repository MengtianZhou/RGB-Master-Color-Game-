<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/profile.css">
<div class='profile'>
	<table>
		<caption>Basic Information</caption>
		<tr>
			<th>Name:</th>
			<td><?php echo $fullname;?></td>
		</tr>
		<tr>
			<th>Email:</th>
			<td><?php echo $email;?></td>
		</tr>
	</table>
</div>


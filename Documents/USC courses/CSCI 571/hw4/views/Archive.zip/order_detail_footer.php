	</table>
	<p class='amount'>Amount: $ <?php echo $amount;?></p>
	<a class='button' href='<?php echo base_url();?>index.php/order/show'>BACK</a>
</div>
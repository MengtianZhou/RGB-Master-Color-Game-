		<tr>
			<td><?php echo $name;?></td>
			<td><img class='product' src='<?php echo base_url();?><?php echo $image;?>'></td>
			<td><?php echo $size;?></td>
			<td><?php echo $price;?></td>
			<td><?php echo $quantity;?></td>
			<td><?php echo $total;?></td>
		</tr>
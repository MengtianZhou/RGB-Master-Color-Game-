			</table>	
		<input type='submit' name='edit' value='edit'>
		<input type='submit' name='delete' value='delete'>
	</form>
</div>
</div>
<div data-role="footer" style='text-align:center;font-size:0.5em'>
	<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
	<p>All Rights Reserved.</p>
</div>
</div> 
</body>
</html>
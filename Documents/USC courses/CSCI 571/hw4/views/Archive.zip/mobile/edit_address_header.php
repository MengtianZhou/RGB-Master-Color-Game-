<div data-role='main' class='content'>
	<form action='<?php echo base_url();?>index.php/account/edit_selected_add' method='post'>
		<table>
			<h3>Select an address to edit</h3>
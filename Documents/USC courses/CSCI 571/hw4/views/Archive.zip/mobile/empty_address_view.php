<div data-role="main" class='content'>
	<table style='margin-left:25px;'>
		<h3>Address List</h3>
		<tr>
			<td>No address existed, please <a href='<?php echo base_url();?>index.php/account/add_address'>add one</a>.</td>
		</tr>
	</table>
</div>
</div>
<div data-role="footer" style='text-align:center;font-size:0.5em'>
	<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
	<p>All Rights Reserved.</p>
</div>
</div> 
</body>
</html>
<div class='content' data-role='main'>
	<p style='color:blue'>There is no order history, <a href='<?php echo base_url();?>index.php/products/show_products_by_category/1'>Shopping now</a>!</p>
	<img style="width:325px; height:350px" src='<?php echo base_url();?>img/website/empty_order.jpg'>
</div>

<div data-role="footer" style='text-align:center;font-size:0.5em'>
	<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
	<p>All Rights Reserved.</p>
</div>
</body>
</html>
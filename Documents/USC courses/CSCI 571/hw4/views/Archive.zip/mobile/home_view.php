<div data-role="main" class="ui-content">
	<img src="<?php echo base_url();?>img/website/001.png" style="width:350px; height:350px">
</div>
<div data-role="footer" style='text-align:center;font-size:0.5em'>
	<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
	<p>All Rights Reserved.</p>
</div>
</div> 
</body>
</html>
  	
    

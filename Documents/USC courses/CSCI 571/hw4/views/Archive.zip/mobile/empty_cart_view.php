<div class='content' data-role='main'>
	<a href='<?php echo base_url();?>index.php/products/show_products_by_category/1'><img style="width:325px; height:350px" src='<?php echo base_url();?>img/website/emptyCart.gif'></a>
</div>

<div data-role="footer" style='text-align:center;font-size:0.5em'>
	<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
	<p>All Rights Reserved.</p>
</div>
</body>
</html>
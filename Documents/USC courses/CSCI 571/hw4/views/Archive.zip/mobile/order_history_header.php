<style>
	table{
		font-size: 12px;
	}
</style>
<div data-role='main' class='content'>
	<table>
		<tr>
			<th>ORDER DATE</th>
			<th>SHIP TO</th>
			<th>BILL TO</th>
			<th>DETAIL</th>
		</tr>
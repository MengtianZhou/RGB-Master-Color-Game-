<style>
table,th,td{
				border-collapse: collapse;
			}
			th,td{
				padding:3px;
				border:1px solid #a6a6a6;
				font-size: 12px;
			}
			table{
				position: relative;
				left: 10px;
				top:20px;
				margin-bottom: 40px;
			}
			tr{
				border:1px solid #a6a6a6;
				text-align: center;
			}
img.product{
                padding: 10px;
                width: 50px;
                height: 30px;
                padding:3px;
                border:solid #000000 5px;
                border-radius: 2px;
                background-color: #F3E2A9;
                box-shadow: 0px 0px 2px #000000;
			}
</style>
<div data-role='main' class="content">
	<table>
		<tr>
			<th>ITEM IMAGE</th>
			<th>ITEM NAME</th>
			<th>SIZE</th>
			<th>PRICE</th>
			<th>QUANTITY</th>
			<th>TOTAL</th>
		</tr>
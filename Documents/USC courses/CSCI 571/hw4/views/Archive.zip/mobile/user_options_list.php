	<div data-role="panel" id="option_list">
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/account/show'>My profile</a>
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/account/edit_profile'>Edit profile</a>
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/account/add_address'>Add new address</a>
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/account/edit_address'>Edit address</a>
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/shopping_cart/show'>Shopping cart</a>
		<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/order/show'>Order history</a>
	</div>
<div data-role="main" class="ui-content">
  	<div data-role="main" class="ui-content">
		<a href="#option_list" class='ui-btn ui-shadow ui-corner-all'>user operations list</a>
	</div>

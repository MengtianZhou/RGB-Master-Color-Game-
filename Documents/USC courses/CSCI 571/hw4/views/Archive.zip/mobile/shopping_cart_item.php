<tr>
	<td><input type='radio' name='p_id' value='<?php echo $p_id;?>'></td>
	<td><img class="product" src='<?php echo base_url();?><?php echo $image;?>'></td>
	<td><?php echo $name;?></td>
	<td><?php echo $size;?></td>
	<td><?php echo $price;?></td>
	<td><?php echo $quantity;?></td>
</tr>
	</table>
	<p style='color:#FF4000;text-align:right;margin-right:20px'>Amount: $ <?php echo $amount;?></p>
	<a class='ui-btn ui-corner-all' href='<?php echo base_url();?>index.php/order/show'>BACK</a>
</div>
</div>
	<div data-role="footer" style='text-align:center;font-size:0.5em'>
		<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
		<p>All Rights Reserved.</p>
	</div>
</div>
</body>
</html>
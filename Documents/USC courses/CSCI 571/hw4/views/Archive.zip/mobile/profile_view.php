<div data-role="main" class='content'>
	<table style='margin-left:25px;'>
		<h3>Basic Information</h3>
		<tr>
			<th>Name:</th>
			<td><?php echo $fullname;?></td>
		</tr>
		<tr>
			<th>Email:</th>
			<td><?php echo $email;?></td>
		</tr>
	</table>
</div>
<tr>
	<th><input type="radio" name="add_id" value="<?php echo $add_id;?>"></th>
	<td style='padding-left:70px'><?php echo "$fullname,<br>$address,$city,$state,$zipcode,<br>phone: $phone";?></td>
</tr>
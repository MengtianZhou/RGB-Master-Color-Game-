<style>
table,th,td{
				border-collapse: collapse;
			}
			th,td{
				padding:3px;
				border:1px solid #a6a6a6;
				font-size: 12px;
			}
			table{
				position: relative;
				left: 10px;
				top:20px;
				margin-bottom: 40px;
			}
			tr{
				border:1px solid #a6a6a6;
				text-align: center;
			}
			
			img.product{
                padding: 10px;
                width: 50px;
                height: 30px;
                padding:3px;
                border:solid #000000 5px;
                border-radius: 2px;
                background-color: #F3E2A9;
                box-shadow: 0px 0px 2px #000000;
			}
</style>
<div data-role='main' class='content'>
	<form action='<?php echo base_url();?>index.php/shopping_cart/edit' method='post'>
		<table>
			<tr>
				<th>select</th>
				<th>product</th>
				<th>name</th>
				<th>size</th>
				<th>price</th>
				<th>quantity</th>
			</tr>
				
		
	



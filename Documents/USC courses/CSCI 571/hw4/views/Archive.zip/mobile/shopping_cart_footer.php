	</table>
	
			<p style='color:#FF4000;text-align:right;margin-right:20px'>Amount:&nbsp;$&nbsp;<?php echo $amount;?></p>
			<input type='submit' class='ui-btn-inline' name='submit' value="continue shopping" style="font-size:13px;margin:10px;display:inline">
			<input type='submit' class='ui-btn-inline' name='submit' value="empty" style="font-size:16px;margin:10px;display:inline">
			<input type="submit" class="ui-btn-inline" name="submit" value="delete" style="font-size:16px; margin:10px;display:inline">
			<input type="submit" class="ui-btn-inline" name="submit" value="edit" style="font-size:16px;margin:10px;display:inline">
			<input type="submit" class="ui-btn-inline" name="submit" value="check out" style="font-size:16px;margin:10px;display:inline">
		</form>	
	</div>
</div>

	<div data-role="footer" style='text-align:center;font-size:0.5em'>
		<p>Copyrigth &copy; 2014-2024 by Mengtian Zhou</p>
		<p>All Rights Reserved.</p>
	</div>
</div>
</body>
</html>